<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Touqa2003\Downloads\internetApp-versioning\internetApp-versioning\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>