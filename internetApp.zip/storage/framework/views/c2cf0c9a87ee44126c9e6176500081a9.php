<?php echo e($slot); ?>

<?php /**PATH C:\Users\Touqa2003\Downloads\internetApp-versioning\internetApp-versioning\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>