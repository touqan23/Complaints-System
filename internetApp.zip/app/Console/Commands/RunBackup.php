<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Spatie\Backup\Tasks\Backup\BackupJobFactory;
use App\Models\BackupLog;
class RunBackup extends Command
{
    protected $signature = 'system:backup';
    protected $description = 'Take a full system backup and upload to S3';

    public function handle()
    {
        try {
            $backupJob = BackupJobFactory::createFromArray(config('backup'));
            $backupJob->run();

            // آخر ملف backup تم إنشاؤه
            $latest = collect(Storage::disk('s3')->files('/'))->last();

            BackupLog::create([
                'file_path' => $latest,
                'disk' => 's3',
                'success' => true,
                'message' => 'Backup completed successfully.'
            ]);

            $this->info("Backup successful");
        } catch (\Exception $e) {
            BackupLog::create([
                'file_path' => null,
                'disk' => 's3',
                'success' => false,
                'message' => $e->getMessage(),
            ]);

            $this->error("Backup failed: " . $e->getMessage());
        }
    }
}
